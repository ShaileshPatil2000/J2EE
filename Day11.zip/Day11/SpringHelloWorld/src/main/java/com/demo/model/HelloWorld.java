package com.demo.model;

public class HelloWorld {
	public HelloWorld() {
		System.out.println("Helloworld default constructor");
		
	}
	public String sayHello() {
		return "Hello World!!";
	}

}
