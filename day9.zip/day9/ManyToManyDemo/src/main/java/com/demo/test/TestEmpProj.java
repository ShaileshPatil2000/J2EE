package com.demo.test;

public class TestEmpProj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
