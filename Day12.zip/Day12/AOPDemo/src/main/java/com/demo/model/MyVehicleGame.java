package com.demo.model;

import org.springframework.stereotype.Component;

@Component
public class MyVehicleGame {
	public void m11(int y) {
		System.out.println("in m11"+y);
	}
	public void game1() {
		System.out.println("in game1");
	}

}
