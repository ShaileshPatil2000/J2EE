package com.demo.dao;

public interface EmployeeDao {

}
